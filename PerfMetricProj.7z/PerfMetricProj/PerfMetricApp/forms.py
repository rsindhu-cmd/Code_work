from django import forms
import sqlite3
import re


class DateForm(forms.Form):
    fromDate = forms.DateField(widget = forms.SelectDateWidget([2017,2018]))
    toDate = forms.DateField(widget = forms.SelectDateWidget([2017,2018]))


class GroupByForm(forms.Form):
    # Group By selections
    Channel = forms.BooleanField(required=False, label='Channel')
    Country = forms.BooleanField(required=False, label='Country')
    OS = forms.BooleanField(required=False, label='OS')


class ResultForm(forms.Form):
        #result = forms.ChoiceField(choices= options, widget=forms.SelectMultiple())
        #firstname = forms.CharField(max_length=100)
    pass


class SortForm(forms.Form):
    SORT_CHOICES=(('asc', 'ascending'),('desc', 'descending'))
    sort = forms.ChoiceField(choices=SORT_CHOICES,widget=forms.RadioSelect)
    METRIC_CHOICES = (('impressions', 'impressions'), ('clicks', 'clicks'), ('installs', 'installs'), ('spend', 'spend'), ('revenue', 'revenue'))
    MetricSort = forms.ChoiceField(choices=METRIC_CHOICES)

class MetricForm(forms.Form):

    #date = forms.ChoiceField(choices=[('date','Date')])
    conn = sqlite3.connect('PerfDB.db')
    cursor = conn.cursor()

    cursor.execute("""SELECT sql FROM sqlite_master
                    WHERE tbl_name = 'dataset' AND type = 'table'""")
    result = cursor.fetchall()
    conn.close()

    #fetch all the column names in "" from the table schema
    MetricInfo = re.findall(r'\"(.+?)\"', result[0][0])
    MetricInfo.remove('dataset')
    MetricInfo.remove('date')
    MetricInfo.remove('channel')
    MetricInfo.remove('country')
    MetricInfo.remove('os')
    MetricInfo.append('CPI')
    print(MetricInfo)

    options = []
    for item in MetricInfo:
        options.append((item,item))

    Metric = forms.ChoiceField(choices= options, widget=forms.SelectMultiple())



