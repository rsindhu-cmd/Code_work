from django.urls import path
from . import views


urlpatterns = [

    path('Result', views.fetchResult, name='Result'),
    path('', views.HomeForm, name='Home')

]
