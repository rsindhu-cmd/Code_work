from django.apps import AppConfig


class PerfMetricAppConfig(AppConfig):
    name = 'PerfMetricApp'
