from django.shortcuts import render
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from .forms import MetricForm, GroupByForm, SortForm, ResultForm, DateForm
import sqlite3
import re
# Create your views here.


def HomeForm(request):
    metric_form = MetricForm()
    group_form = GroupByForm()
    sort_form = SortForm()
    date_form = DateForm()

    if request.method == 'POST':

        data = request.POST.copy()
        #print(data)

        Filter_opt = data.getlist('Metric',[])

        query_str = """select """

        gform = GroupByForm(request.POST)
        group_opt =""
        if gform.is_valid():
            group_opt = gform.cleaned_data

        group_by =[]
        for key, value in group_opt.items():
            if value == True:
                group_by.append(key)

        if len(group_by) != 0:
            for item in group_by:
                query_str = query_str + item + ", "
        i=0
        for item in Filter_opt:
            i = i + 1
            if len(Filter_opt) == i:
                if len(group_by) == 0:
                    query_str = query_str + item
                else:
                    query_str = query_str + " sum(" +item +" ) as " + item
            else:

                if len(group_by) == 0:
                    query_str = query_str + item + ", "
                else:
                    query_str = query_str + " sum(" +item +" ) as " + item + ", "

        query_str = query_str + " from dataset where date <= '2017-06-01' "

        if len(group_by) != 0:
            query_str = query_str + " group by "
            i =0
            for item in group_by:
                i= i+1
                if len(group_by)  == i:
                    query_str = query_str + item +" "
                else:
                    query_str = query_str + item +" and "

        sort_metric = data.getlist('MetricSort', [])

        sort_opt = data.getlist('sort', [])

        query_str = query_str + "order by " + sort_metric[0] + " " + sort_opt[0]
        print(query_str)

        ### fetch result code
        conn = sqlite3.connect('PerfDB.db')
        cursor = conn.cursor()

        cursor.execute(query_str)

        result = cursor.fetchall()
        conn.close()
        context = {
            'date_from': date_form,
            'metric_form': metric_form,
            'group_form': group_form,
            'sort_form': sort_form,
            'form': result
        }
        return render(request, 'PerfMetricApp/PerfMetric.html', context)

    else:

        context = {
            'date_from': date_form,
            'metric_form':metric_form,
            'group_form':group_form,
            'sort_form':sort_form
        }
        return render(request, 'PerfMetricApp/PerfMetric.html',context)




def fetchResult(request):


    conn = sqlite3.connect('PerfDB.db')
    cursor = conn.cursor()

    cursor.execute("""select channel, country, sum(impressions) as impressions, sum(clicks) as clicks from
            dataset where date <= '2017-06-01' group by channel, country order by clicks desc""")

    result = cursor.fetchall()
    conn.close()

    print(result)
    return render(request, 'PerfMetricApp/Result.html', {'form': result})


